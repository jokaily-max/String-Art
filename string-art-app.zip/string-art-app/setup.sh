#!/bin/bash

echo "================================"
echo "String Art App - Quick Setup"
echo "================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed"
    echo "Please install Node.js from: https://nodejs.org/"
    exit 1
fi

echo "✓ Node.js found"

# Check if Cordova is installed
if ! command -v cordova &> /dev/null; then
    echo "Installing Cordova..."
    npm install -g cordova
fi

echo "✓ Cordova ready"
echo ""

# Create Cordova project
echo "Creating Cordova project..."
cordova create StringArtApp com.stringart.app "String Art"
cd StringArtApp

# Add Android platform
echo "Adding Android platform..."
cordova platform add android

# Copy HTML file
echo "Copying app files..."
cp ../index.html www/index.html

# Update config.xml for better mobile experience
cat > config.xml << 'EOF'
<?xml version='1.0' encoding='utf-8'?>
<widget id="com.stringart.app" version="1.0.0" xmlns="http://www.w3.org/ns/widgets">
    <name>String Art</name>
    <description>Create beautiful geometric string art patterns</description>
    <author email="dev@stringart.com" href="https://stringart.app">
        String Art Team
    </author>
    <content src="index.html" />
    <preference name="Orientation" value="portrait" />
    <preference name="Fullscreen" value="true" />
    <preference name="StatusBarOverlaysWebView" value="true" />
    <preference name="StatusBarBackgroundColor" value="#4a6fa5" />
    <preference name="DisallowOverscroll" value="true" />
    <platform name="android">
        <preference name="AndroidXEnabled" value="true" />
        <preference name="AndroidWindowSplashScreenAnimatedIcon" value="res/icon/android/icon.png" />
        <allow-intent href="market:*" />
    </platform>
</widget>
EOF

echo ""
echo "================================"
echo "Setup Complete!"
echo "================================"
echo ""
echo "To build the APK, run:"
echo "  cd StringArtApp"
echo "  cordova build android"
echo ""
echo "APK will be in:"
echo "  platforms/android/app/build/outputs/apk/debug/"
echo ""
echo "To install directly on connected device:"
echo "  cordova run android"
echo ""
